package com.ust.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ust.entity.Customer;
import com.ust.model.Response;
import com.ust.service.CustomerService;

@RestController
@RequestMapping(value = "/customer")
public class CustomerController {

	@Autowired
	public CustomerService customerService;
	
	@PostMapping(value = "/addCustomer")
	public ResponseEntity<Response> addCustomer(@RequestBody Customer customer) {
		Response response = customerService.addCustomer(customer);
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}
	
	@PutMapping(value = "/updateCustomer")
	public ResponseEntity<Response> updateCustomer(@RequestBody Customer customer){
		Response response=customerService.updateCustomer(customer);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	
	@DeleteMapping(value = "/deleteCustomer")
	public ResponseEntity<Response> deleteCustomer(@RequestBody Customer customer){
		Response response=customerService.deleteCustomer(customer);
		return new ResponseEntity<Response>(response ,HttpStatus.OK);
		
	}
	
	@GetMapping(value = "/list")
	public ResponseEntity<Response> showList() {
		Response response = customerService.showList();
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}
	
	
	
//	
//	@PutMapping(value = "/updateCustomer/{id}")
//	public ResponseEntity<Response> updateCustomer(@PathVariable("id") long accNo){
//		Customer cust = new Customer();
//		cust.setAccount_no(accNo);
//		Response response=customerService.updateCustomer( Branch_Id);
//		return new ResponseEntity<Response>(response ,HttpStatus.OK);
//		
//	}
}
